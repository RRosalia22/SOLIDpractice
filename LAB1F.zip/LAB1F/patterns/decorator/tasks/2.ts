class Computer {
    components: string[] = [];

    addComponent(component: string) {
        this.components.push(component);
    }

    showConfiguration() {
        console.log(`This computer has: ${this.components.join(', ')}`);
    }
}

const myComputer = new Computer();
myComputer.addComponent('16GB RAM');
myComputer.addComponent('1TB SSD');
myComputer.addComponent('Intel i7 Processor');
myComputer.showConfiguration();

////////////////////////////////////////////////////////////
// Interfaz que representa los componentes decoradores
interface ComputerDecorator {
    addComponent(component: string): void;
}

// Clase base Computer
class Computer implements ComputerDecorator {
    components: string[] = [];

    addComponent(component: string) {
        this.components.push(component);
    }

    showConfiguration() {
        console.log(`This computer has: ${this.components.join(', ')}`);
    }
}

// Clase concreta de decorador para añadir una GPU
class GpuDecorator implements ComputerDecorator {
    constructor(private computer: Computer, private gpu: string) {}

    addComponent(component: string) {
        this.computer.addComponent(component);
        this.computer.addComponent(`GPU: ${this.gpu}`);
    }

    showConfiguration() {
        this.computer.showConfiguration();
    }
}

// Clase concreta de decorador para añadir una monitor
class MonitorDecorator implements ComputerDecorator {
    constructor(private computer: Computer, private monitor: string) {}

    addComponent(component: string) {
        this.computer.addComponent(component);
        this.computer.addComponent(`Monitor: ${this.monitor}`);
    }

    showConfiguration() {
        this.computer.showConfiguration();
    }
}

// Crear una instancia de Computer y decorarla con GPU y monitor
const myComputer = new Computer();
const computerWithGpu = new GpuDecorator(myComputer, 'NVIDIA RTX 3080');
const computerWithMonitor = new MonitorDecorator(computerWithGpu, '27" 4K Monitor');

computerWithMonitor.addComponent('16GB RAM');
computerWithMonitor.addComponent('1TB SSD');
computerWithMonitor.addComponent('Intel i7 Processor');
computerWithMonitor.showConfiguration();

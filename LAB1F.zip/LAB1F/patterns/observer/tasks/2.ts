class Auction {
    item: string;
    currentBid: number = 0;
    highestBidder: string | null = null;

    constructor(item: string) {
        this.item = item;
    }

    makeBid(bidderName: string, amount: number) {
        if (amount > this.currentBid) {
            this.currentBid = amount;
            this.highestBidder = bidderName;
            console.log(`${bidderName} es el máximo postor con una oferta de ${amount}`);
        } else {
            console.log(`${bidderName}, tu oferta es demasiado baja.`);
        }
    }
}

const auctionItem = new Auction("Cuadro famoso");
auctionItem.makeBid("Carlos", 500);
auctionItem.makeBid("Ana", 450);

//////////////////////////////////////////////////
// Clase Observer para representar a los licitadores
class Bidder {
    constructor(private name: string) {}

    update(item: string, amount: number) {
        console.log(`${this.name} ha sido informado de una nueva oferta en el artículo '${item}' por un monto de ${amount}`);
    }
}

// Clase Auction que implementa el patrón Observer
class Auction {
    item: string;
    currentBid: number = 0;
    highestBidder: string | null = null;
    bidders: Bidder[] = [];

    constructor(item: string) {
        this.item = item;
    }

    addObserver(bidder: Bidder) {
        this.bidders.push(bidder);
    }

    makeBid(bidderName: string, amount: number) {
        if (amount > this.currentBid) {
            this.currentBid = amount;
            this.highestBidder = bidderName;
            console.log(`${bidderName} es el máximo postor con una oferta de ${amount}`);
            this.notifyBidders();
        } else {
            console.log(`${bidderName}, tu oferta es demasiado baja.`);
        }
    }

    private notifyBidders() {
        for (const bidder of this.bidders) {
            bidder.update(this.item, this.currentBid);
        }
    }
}

// Crear una instancia de Auction y agregar observadores (licitadores)
const auctionItem = new Auction("Cuadro famoso");
const bidder1 = new Bidder("Carlos");
const bidder2 = new Bidder("Ana");

auctionItem.addObserver(bidder1);
auctionItem.addObserver(bidder2);

auctionItem.makeBid("Carlos", 500);
auctionItem.makeBid("Ana", 450);

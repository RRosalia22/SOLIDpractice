class Product {
    id: number;
    name: string;
    price: number;

    constructor(id: number, name: string, price: number) {
        this.id = id;
        this.name = name;
        this.price = price;
    }
}

class Cart {
    products: Product[] = [];

    addProduct(product: Product) {
        this.products.push(product);
    }

    calculateTotal(): number {
        let total = this.products.reduce((acc, product) => acc + product.price, 0);

        // Descuento: 10% si hay más de 5 productos
        if (this.products.length > 5) {
            total *= 0.9;
        }

        // Envío: $10 si la compra es menor a $50
        if (total < 50) {
            total += 10;
        }

        return total;
    }
}
///////////////////////////////////////
class Product {
    private id: number;
    private name: string;
    private price: number;

    constructor(id: number, name: string, price: number) {
        this.id = id;
        this.name = name;
        this.price = price;
    }

    getId(): number {
        return this.id;
    }

    getName(): string {
        return this.name;
    }

    getPrice(): number {
        return this.price;
    }
}

class Cart {
    private products: Product[] = [];

    addProduct(product: Product) {
        this.products.push(product);
    }

    private calculateDiscountedTotal(total: number): number {
        if (this.products.length > 5) {
            return total * 0.9;
        }
        return total;
    }

    private calculateShippingCost(total: number): number {
        if (total < 50) {
            return 10;
        }
        return 0;
    }

    calculateTotal(): number {
        const total = this.products.reduce((acc, product) => acc + product.getPrice(), 0);
        const discountedTotal = this.calculateDiscountedTotal(total);
        const totalWithShipping = discountedTotal + this.calculateShippingCost(discountedTotal);
        return totalWithShipping;
    }
}


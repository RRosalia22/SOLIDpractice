class Cinema {
    movies: any[] = [];
    snacks: any[] = [];
    tickets: any[] = [];
    employees: any[] = [];

    // Métodos relacionados con películas
    addMovie(movie: any) {
        this.movies.push(movie);
    }

    // Métodos relacionados con snacks
    buySnack(snack: any) {
        this.snacks.push(snack);
    }

    // Métodos relacionados con entradas
    buyTicket(ticket: any) {
        this.tickets.push(ticket);
    }

    // Métodos relacionados con empleados
    hireEmployee(employee: any) {
        this.employees.push(employee);
    }
}
/////////////////////////////////
class Movie {
    // Métodos relacionados con películas
    addMovie(movie: any) {
        // Implementación
    }
}

class SnackShop {
    // Métodos relacionados con snacks
    buySnack(snack: any) {
        // Implementación
    }
}

class TicketOffice {
    // Métodos relacionados con entradas
    buyTicket(ticket: any) {
        // Implementación
    }
}

class EmployeeManagement {
    // Métodos relacionados con empleados
    hireEmployee(employee: any) {
        // Implementación
    }
}
